package com.example.strayapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class WildReport extends AppCompatActivity {

    private Button homebutton;
    private Button homebutton2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wild_report);


        homebutton = (Button)findViewById(R.id.homebutton);
        homebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });

        homebutton2 = (Button)findViewById(R.id.submitbutton);
        homebutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText color = (EditText)findViewById(R.id.colortype);
                EditText desc = (EditText)findViewById(R.id.descriptiontype);
                EditText type = (EditText)findViewById(R.id.animaltype);
                String colortext = color.getText().toString();
                String desctext = desc.getText().toString();
                String typetext = type.getText().toString();
                if(colortext.length() == 0 || desctext.length() == 0 || typetext.length() == 0){
                    Snackbar error = Snackbar.make(view, "Please fill all fields!", 2500);
                    error.show();
                }
                else{

                    openMainActivity();
                }
            }
        });

    }
    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        setContentView(R.layout.activity_wild_report);
    }
}