package com.example.strayapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ReportMenu extends AppCompatActivity {
    private Button homebutton;
    private Button petbutton;
    private Button wildbutton;
    private Button threatbutton;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reportmenu);

        homebutton = (Button)findViewById(R.id.homebutton);
        homebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });
        petbutton = (Button)findViewById(R.id.petbutton);
        petbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPetReport();
            }
        });
        threatbutton = (Button)findViewById(R.id.threatbuttonGOAT);
        threatbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openThreatReport();
            }
        });
        wildbutton = (Button)findViewById(R.id.wildbutton);
        wildbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { openWildReport();}
        });
    }
    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        setContentView(R.layout.activity_reportmenu);
    }
    public void openPetReport() {
        Intent intent = new Intent(this, PetReport.class);
        startActivity(intent);
        setContentView(R.layout.activity_reportmenu);
    }
    public void openThreatReport() {
        Intent intent = new Intent(this, ThreatReport.class);
        startActivity(intent);
        setContentView(R.layout.activity_reportmenu);
    }
    public void openWildReport() {
        Intent intent = new Intent(this, WildReport.class);
        startActivity(intent);
        setContentView(R.layout.activity_reportmenu);
    }
}